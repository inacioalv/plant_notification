package com.inacioalves.microservice.user_plant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserPlantApplicationTests {

	@Test
	void contextLoads() {
	}

}
