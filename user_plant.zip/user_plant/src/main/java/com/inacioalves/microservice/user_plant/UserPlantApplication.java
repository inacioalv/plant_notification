package com.inacioalves.microservice.user_plant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserPlantApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserPlantApplication.class, args);
	}

}
