package com.inacioalves.microservice.gateway_plant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GatewayPlantApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatewayPlantApplication.class, args);
	}

}
