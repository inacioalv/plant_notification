package com.inacioalves.microservice.gateway_plant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GatewayPlantApplicationTests {

	@Test
	void contextLoads() {
	}

}
