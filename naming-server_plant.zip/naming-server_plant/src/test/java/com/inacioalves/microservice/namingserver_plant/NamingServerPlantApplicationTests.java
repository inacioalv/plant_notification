package com.inacioalves.microservice.namingserver_plant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NamingServerPlantApplicationTests {

	@Test
	void contextLoads() {
	}

}
