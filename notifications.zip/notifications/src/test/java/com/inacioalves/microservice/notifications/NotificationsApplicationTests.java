package com.inacioalves.microservice.notifications;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NotificationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
